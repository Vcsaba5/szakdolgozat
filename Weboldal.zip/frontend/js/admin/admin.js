// Sorozatok lekérdezése
async function fetchAirsoft() {
    const response = await fetch('/airsoft');
    const airsoft = await response.json();

    seriesDrawing(airsoft);
}

// sorozat felvétele
document.getElementById('create-series').onsubmit = async function (event) {
    event.preventDefault();

    const name = event.target.elements.name.value;
    const season = event.target.elements.season.value;
    const image = event.target.elements.image.files[0]

    const formData = new FormData();
    formData.append('name', name);
    formData.append('season', season);
    formData.append('image', image);

    const res = await fetch('/airsoft', {
        method: "POST",
        body: formData
    });

    if (res.ok) {
        alert("Sikeres felvétel!");
        event.target.elements.name.value = null;
        event.target.elements.season.value = null;
        fetchAirsoft();
    } else {
        alert("Hiba a felvétel során!");
    }
}

// sorozat törlése
async function deleteSeries(id) {
    const confirmed = confirm("Biztosan törölni szeretnéd?");

    if (!confirmed) {
        return;
    }

    const res = await fetch(`/airsoft/${id}`, {
        method: "DELETE"
    });

    if (res.ok) {
        alert("Sikeres törlés!");
        fetchAirsoft();
    } else {
        alert("Hiba a törlés során!");
    }
}

// --- sorozat szerkesztése ---

// modal ablak mutatása, és a megfelelő id eltárolása a modal-on belül
async function editSeries(id) {
    console.log(id);
    const res = await (fetch(`/series/${id}`));
    const dataFromFetch = await res.json();

    const name = dataFromFetch[0].name;
    const season = dataFromFetch[0].season;

    document.getElementById('seriesName').value = name;
    document.getElementById('seriesSeason').value = season;

    // ---
    // itt hozzáadjuk a sorozat id-ját a modal ablak attribútumaihoz
    // ---
    const modal = new bootstrap.Modal(document.getElementById('updateSeriesModal'));
    const seriesID = document.getElementById('updateSeriesModal');
    seriesID.setAttribute('data-seriesID', id);
    modal.show();
}

// a backend-el való kapcsolatfelvétel
async function updateSeriesData() {
    const modalElements = document.getElementById('updateSeriesModal');
    const id = modalElements.getAttribute('data-seriesID');
    const modal = bootstrap.Modal.getInstance(modalElements);

    const name = document.getElementById('seriesName').value;
    const season = document.getElementById('seriesSeason').value;
    const image = document.getElementById('seriesImage').files[0];

    const formData = new FormData();
    formData.append('name', name);
    formData.append('season', season);
    formData.append('image', image);

    const res = await fetch(`/airsoft/${id}`, {
        method: "PUT",
        body: formData
    });

    if (res.ok) {
        modal.hide();
        alert("Sikeres módosítás!");
        fetchAirsoft();
        resetInput();
    }
    else {
        alert("Hiba a szerkesztés során!");
    }
}

// modal ablak beviteli mezőinek kiürítése
function resetInput() {
    document.getElementById('seriesName').value = null;
    document.getElementById('seriesSeason').value = null;
}

// keresés a sorozatok között
document.getElementById('searchingForm').onsubmit = async function (event) {
    event.preventDefault();

    const searching = event.target.elements.searching.value;

    const res = await fetch('/searching', {
        method: "POST",
        headers: {
            "content-type": "application/json"
        },
        body: JSON.stringify({ searching })
    });

    const airsoftok = await res.json();

    if (airsoftok.length === 0) {
        document.getElementById('series-list').innerHTML = '<h3 class="text-center m-4">Nincs találat</h3>';
    } else {
        seriesDrawing(airsoftok);
    }
}

// sorozatok kirajzoltatása
function seriesDrawing(airsoftok) {
    let seriesHTML = '<h1 class="mt-2 mb-2"></h1>';
    for (let sorozat of airsoftok) {
        seriesHTML += `
            <div class="col-xl-3 col-md-4 col-sm-6 my-2">
                <div class="card bg-dark text-white my-2 h-100">
                    <div class="card-header">
                        <img src="/images/${airsoft.image}" alt="${airsoft.name}" title="${airsoftt.name}" class="img img-fluid img-thumbnail mx-auto d-block">
                    </div>
                    <div class="card-body">
                        <h3>${sorozat.name}</h3>
                        <h5>${sorozat.season}</h5>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-outline-danger me-2" onclick="deleteSeries(${sorozat.seriesID})"><i class="fa-solid fa-trash"></i></button>
                        <button class="btn btn-warning" onclick="editSeries(${sorozat.seriesID})"><i class="fa-solid fa-pen"></i></button>
                    </div>
                </div>
            </div>
        `
    }

    document.getElementById('series-list').innerHTML = seriesHTML;
}
