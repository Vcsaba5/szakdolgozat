const express = require('express');
const connection = require('../../middleware/database.js');
const upload = require('../../middleware/upload.js');
const router = express.Router();

// sorozatok lekérdezése route
router.get('/termek', function (req, res) {
    connection.query('SELECT * FROM airsoft', (err, result) => {
        res.json(result);
    });
});

// egy konkrét sorozat lekérdezése seriesID alapján route
router.get('/termek/:id', function (req, res) {
    const id = req.params.id;

    connection.query('SELECT * FROM airsoft WHERE termekID=?', [id], (err, result) => {
        res.json(result);
    });
});

// sorozatok lekérdezése userID alapján
router.get('/termekUser/:id', function (req, res) {
    const id = req.params.id;

    connection.query('SELECT termek.termekID, termek.name, termek.termektipus, termek.image, termek.rating, COALESCE(r.rating, 0) AS userRating FROM airsoft termek LEFT JOIN (SELECT termekID, rating FROM rating WHERE userID = ?) r USING (termekID);', [id], (err, result) => {
        res.json(result);
    });
});

// egy sorozat lekérdezése mobilra email alapján
router.get('/termekekMobil/:termekID/:userID', function(req, res) {
    const termekID = req.params.termekID;
    const userID = req.params.userID;
    
    connection.query('SELECT t.termekID, t.name, t.termektipus, s.image, s.rating, COALESCE(r.rating, 0) AS userRating FROM termek s LEFT JOIN (SELECT termekID, rating FROM rating WHERE userID = ?) r USING (termekID) WHERE a.termekID = ?;', [userID, termekID], (err, result) => {
        res.json(result);
    });
});

// sorozat létrehozása route
router.post('/termekek', upload.single('image'), function (req, res) {
    const { name, season } = req.body; // destruktálás = szétbontás
    const imageName = req.file ? req.file.filename : 'no_image.png';

    connection.query('INSERT INTO termek(termekID, name, termektipus, image, rating) VALUES (NULL, ?, ?, ?, 0)', [name, termektipus, imageName], (err, result) => {
        if (err) {
            console.log(err);
        }
        res.json("Sikeres felvétel!");
    });
});

// sorozat törlése route
router.delete('/termekek/:id', function (req, res) {
    const id = req.params.id;

    connection.query('DELETE FROM termek WHERE termekID=?', [id], (err, result) => {
        res.json("Sikeres törlés!");
    });
});

// sorozat szerkesztése route
router.put('/termek/:id', upload.single('image'), function (req, res) {
    const id = req.params.id;
    const { name, season } = req.body;
    const imageName = req.file ? req.file.filename : null;

    connection.query('UPDATE termek SET name = ?, termektipus = ?, image = COALESCE(?, image) WHERE termek.termekID = ?;', [name, termektipus, imageName, id], (err, result) => {
        res.json("Sikeres módosítás!");
    });
});

// sorozatok közti keresés
router.post('/searching', function (req, res) {
    const searching = req.body.searching;

    connection.query('SELECT * FROM termek WHERE name LIKE CONCAT("%", ?, "%") OR termektipus LIKE CONCAT("%", ?, "%")', [searching, searching], (err, result) => {
        res.json(result);
    });
});

// sorozatok közti keresés userID alapján
router.post('/searchingUser/:id', function (req, res) {
    const id = req.params.id;
    const searching = req.body.searching;

    connection.query('SELECT termek.*, rating.rating AS userRating FROM termek JOIN rating USING(termekID) WHERE (name LIKE CONCAT("%", ?, "%") OR termektipus LIKE CONCAT("%", ?, "%")) AND rating.userID = ?;', [searching, searching, id], (err, result) => {
        if (err) {
            console.log(err);
        }
        console.log(result);
        res.json(result);
    });
});

// egy adott sorozat értékelésének rögzítése egy adott felhasználótól
router.put('/rating/:termekID/:userID', function (req, res) {
    const seriesID = req.params.seriesID;
    const userID = req.params.userID;
    let rating = req.body.rating;

    connection.query('SELECT * FROM rating WHERE termekID = ? AND userID = ?', [termekID, userID], async (err, result) => {
        if (result.length === 0) {
            // Nincs még értékelés az adott sorozathoz az adott felhasználótól
            connection.query('INSERT INTO rating (ratingID, rating, userID, termekID) VALUES (NULL, ?, ?, ?)', [rating, userID, termekID], (err, result) => {
                updateAvgRating(seriesID, res);
            });
        } else {
            // Már van értékelés az adott sorozathoz az adott felhasználótól, ezért frissíteni kell
            connection.query('UPDATE rating SET rating = ? WHERE seriesID = ? AND userID = ?', [rating, termekID, userID], (err, result) => {
                updateAvgRating(seriesID, res);
            });
        }
    });
});

// az adott sorozat összértékelésének átlagának beszúrása
function updateAvgRating(seriesID, res) {
    connection.query('UPDATE termek SET rating = (SELECT AVG(rating) FROM rating WHERE termekID = ?) WHERE termekID = ?', [termekID, termekID], (err, result) => {
        res.json({ success: true });
    });
}

// az ár kiszámítása és az elérhető darabszám csökkentése
router.post('/ordering/:id', function(req, res) {
    const id = req.params.id;
    const stock = req.body.stock;

    connection.query('SELECT stock, price FROM termek WHERE termekID = ?', [id], (err, result) => {
        if (result[0].stock >= stock) {
            const buy = result[0].stock - stock;
            const price = result[0].price * stock;

            connection.query('UPDATE termek SET stock = ? WHERE termekID = ?', [buy, id], (err, result2) => {
                res.send({ success : true, price : price });
            })
        } else {
            res.send({ success: false, available : result[0].stock });
        }
    });
});

// a rendelés leadása
router.post('/payment', function (req, res) {
    const { price, seriesID, userID } = req.body;

    const date = new Date();
    const orderDate = date.toISOString().slice(0, 19).replace('T', ' ');

    connection.query('INSERT INTO ordering(orderID, userID, termekID, orderDate, price) VALUES (NULL, ?, ?, ?, ?)', [userID, seriesID, orderDate, price], (err, result) => {
        res.json({ success : true })
    })
});

module.exports = router;